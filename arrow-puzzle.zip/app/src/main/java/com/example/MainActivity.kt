package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.AppDatabase
import com.example.data.ProgressRepository
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GameScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameViewModel
import com.example.viewmodel.GameViewModelFactory

import com.example.data.UserPreferences

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.ads.AdsManager
import com.example.ui.screens.PrivacyConsentDialog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val database = AppDatabase.getDatabase(this)
        val repository = ProgressRepository(database.progressDao())
        val userPreferences = UserPreferences(this)

        setContent {
            val hasGivenConsent by userPreferences.hasGivenConsent.collectAsState()
            val context = LocalContext.current

            LaunchedEffect(hasGivenConsent) {
                if (hasGivenConsent) {
                    AdsManager.setConsent(true, context)
                    AdsManager.initialize(context)
                }
            }

            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!hasGivenConsent) {
                        PrivacyConsentDialog(onAccept = {
                            userPreferences.setConsent(true)
                        })
                    }

                    val navController = rememberNavController()
                    val gameViewModel: GameViewModel = viewModel(
                        factory = GameViewModelFactory(repository, userPreferences)
                    )

                    NavHost(navController = navController, startDestination = "splash") {
                        composable("splash") {
                            com.example.ui.screens.SplashScreen(onSplashFinished = {
                                navController.navigate("home") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            })
                        }
                        composable("home") {
                            com.example.ui.screens.HomeScreen(
                                progressRepository = repository,
                                onNavigateToLevels = { navController.navigate("dashboard") },
                                onNavigateToShop = { navController.navigate("shop") },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToDaily = { navController.navigate("daily_challenge") },
                                onNavigateToAchievements = { navController.navigate("achievements") }
                            )
                        }
                        composable("shop") {
                            com.example.ui.screens.ShopScreen(
                                userPreferences = userPreferences,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            com.example.ui.screens.SettingsScreen(onBack = { navController.popBackStack() })
                        }
                        composable("achievements") {
                            com.example.ui.screens.AchievementsScreen(onBack = { navController.popBackStack() })
                        }
                        composable("daily_challenge") {
                            com.example.ui.screens.DailyChallengeScreen(onBack = { navController.popBackStack() })
                        }
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = gameViewModel,
                                progressRepository = repository,
                                onLevelSelected = { levelId ->
                                    gameViewModel.loadLevel(levelId)
                                    navController.navigate("game/$levelId")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            "game/{levelId}",
                            arguments = listOf(navArgument("levelId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val levelId = backStackEntry.arguments?.getInt("levelId") ?: 1
                            GameScreen(
                                viewModel = gameViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}