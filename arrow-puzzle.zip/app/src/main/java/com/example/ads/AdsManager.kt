package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object AdsManager {
    private const val TAG = "AdsManager"
    const val GAME_ID = "6094029"
    const val TEST_MODE = false // Live Production Ads
    const val PLACEMENT_REWARDED = "Rewarded_Android"
    const val PLACEMENT_INTERSTITIAL = "Interstitial_Android"
    const val PLACEMENT_BANNER = "Banner_Android"
    
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized = _isInitialized.asStateFlow()

    fun initialize(context: Context, onInitComplete: () -> Unit = {}) {
        if (_isInitialized.value) {
            onInitComplete()
            return
        }

        UnityAds.initialize(context, GAME_ID, TEST_MODE, object : IUnityAdsInitializationListener {
            override fun onInitializationComplete() {
                Log.d(TAG, "Unity Ads Initialization Complete")
                _isInitialized.value = true
                onInitComplete()
                loadAd(PLACEMENT_INTERSTITIAL)
                loadAd(PLACEMENT_REWARDED)
            }

            override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {
                Log.e(TAG, "Unity Ads Initialization Failed: $error - $message")
            }
        })
    }
    
    fun setConsent(hasConsent: Boolean, context: Context) {
        val metaData = com.unity3d.ads.metadata.MetaData(context)
        metaData.set("gdpr.consent", hasConsent)
        metaData.set("privacy.consent", hasConsent)
        metaData.commit()
    }

    private fun loadAd(placementId: String) {
        UnityAds.load(placementId, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String) {
                Log.d(TAG, "Ad Loaded: $placementId")
            }

            override fun onUnityAdsFailedToLoad(placementId: String, error: UnityAds.UnityAdsLoadError, message: String) {
                Log.e(TAG, "Ad Failed to load: $placementId, $error, $message")
            }
        })
    }

    fun showInterstitial(activity: Activity) {
        if (!_isInitialized.value) return
        UnityAds.show(activity, PLACEMENT_INTERSTITIAL, object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(placementId: String, error: UnityAds.UnityAdsShowError, message: String) {
                Log.e(TAG, "Interstitial show failure: $message")
                loadAd(placementId)
            }

            override fun onUnityAdsShowStart(placementId: String) {}

            override fun onUnityAdsShowClick(placementId: String) {}

            override fun onUnityAdsShowComplete(placementId: String, state: UnityAds.UnityAdsShowCompletionState) {
                loadAd(placementId)
            }
        })
    }

    fun showRewarded(activity: Activity, onRewarded: () -> Unit) {
        if (!_isInitialized.value) {
            Log.e(TAG, "Unity Ads not initialized yet")
            return
        }
        UnityAds.show(activity, PLACEMENT_REWARDED, object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(placementId: String, error: UnityAds.UnityAdsShowError, message: String) {
                Log.e(TAG, "Rewarded show failure: $message")
                loadAd(placementId)
            }

            override fun onUnityAdsShowStart(placementId: String) {}

            override fun onUnityAdsShowClick(placementId: String) {}

            override fun onUnityAdsShowComplete(placementId: String, state: UnityAds.UnityAdsShowCompletionState) {
                if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                    onRewarded()
                }
                loadAd(placementId)
            }
        })
    }
}

@Composable
fun BannerAdView(modifier: Modifier = Modifier) {
    val isInitialized by AdsManager.isInitialized.collectAsStateWithLifecycle()

    if (isInitialized) {
        AndroidView(
            modifier = modifier.fillMaxWidth().wrapContentHeight(),
            factory = { context ->
                val bannerView = BannerView((context as Activity), AdsManager.PLACEMENT_BANNER, UnityBannerSize(320, 50))
                bannerView.listener = object : BannerView.IListener {
                    override fun onBannerLoaded(bannerAdView: BannerView) {
                        Log.d("BannerAd", "Banner loaded")
                    }

                    override fun onBannerClick(bannerAdView: BannerView) {}

                    override fun onBannerFailedToLoad(bannerAdView: BannerView, errorInfo: BannerErrorInfo) {
                        Log.e("BannerAd", "Banner failed: ${errorInfo.errorMessage}")
                    }

                    override fun onBannerLeftApplication(bannerAdView: BannerView) {}

                    override fun onBannerShown(bannerAdView: BannerView) {}
                }
                bannerView.load()
                bannerView
            }
        )
    }
}
