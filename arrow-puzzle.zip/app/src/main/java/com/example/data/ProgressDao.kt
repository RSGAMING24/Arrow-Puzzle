package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM player_progress")
    fun getAllProgress(): Flow<List<PlayerProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: PlayerProgress)

    @Query("SELECT * FROM player_progress WHERE levelId = :levelId")
    suspend fun getProgressForLevel(levelId: Int): PlayerProgress?
}
