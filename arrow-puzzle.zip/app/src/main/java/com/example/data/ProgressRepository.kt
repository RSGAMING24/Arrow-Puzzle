package com.example.data

import kotlinx.coroutines.flow.Flow

class ProgressRepository(private val progressDao: ProgressDao) {
    val allProgress: Flow<List<PlayerProgress>> = progressDao.getAllProgress()

    suspend fun saveProgress(levelId: Int, stars: Int) {
        val existing = progressDao.getProgressForLevel(levelId)
        val bestStars = if (existing != null) maxOf(existing.stars, stars) else stars
        progressDao.insertProgress(PlayerProgress(levelId, bestStars, true))
    }
}
