package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)

    private val _coins = MutableStateFlow(prefs.getInt("coins", 1450))
    val coins: StateFlow<Int> = _coins.asStateFlow()

    private val _hints = MutableStateFlow(prefs.getInt("hints", 2))
    val hints: StateFlow<Int> = _hints.asStateFlow()

    private val _lives = MutableStateFlow(prefs.getInt("lives", 3))
    val lives: StateFlow<Int> = _lives.asStateFlow()

    private val _shields = MutableStateFlow(prefs.getInt("shields", 0))
    val shields: StateFlow<Int> = _shields.asStateFlow()

    private val _skips = MutableStateFlow(prefs.getInt("skips", 0))
    val skips: StateFlow<Int> = _skips.asStateFlow()

    private val _equippedSkin = MutableStateFlow(prefs.getString("skin", "skin_default") ?: "skin_default")
    val equippedSkin: StateFlow<String> = _equippedSkin.asStateFlow()

    private val _equippedTheme = MutableStateFlow(prefs.getString("theme", "theme_default") ?: "theme_default")
    val equippedTheme: StateFlow<String> = _equippedTheme.asStateFlow()

    private val _equippedEffect = MutableStateFlow(prefs.getString("effect", "effect_default") ?: "effect_default")
    val equippedEffect: StateFlow<String> = _equippedEffect.asStateFlow()

    private val _unlockedItems = MutableStateFlow(prefs.getStringSet("unlocked", setOf("skin_default", "theme_default", "effect_default")) ?: setOf())
    val unlockedItems: StateFlow<Set<String>> = _unlockedItems.asStateFlow()

    fun addCoins(amount: Int) {
        val newAmount = _coins.value + amount
        prefs.edit().putInt("coins", newAmount).apply()
        _coins.value = newAmount
    }

    fun spendCoins(amount: Int): Boolean {
        if (_coins.value >= amount) {
            val newAmount = _coins.value - amount
            prefs.edit().putInt("coins", newAmount).apply()
            _coins.value = newAmount
            return true
        }
        return false
    }

    fun addHints(amount: Int) {
        val newAmount = _hints.value + amount
        prefs.edit().putInt("hints", newAmount).apply()
        _hints.value = newAmount
    }
    
    fun useHint(): Boolean {
        if (_hints.value > 0) {
            val newAmount = _hints.value - 1
            prefs.edit().putInt("hints", newAmount).apply()
            _hints.value = newAmount
            return true
        }
        return false
    }

    fun addLives(amount: Int) {
        val newAmount = _lives.value + amount
        prefs.edit().putInt("lives", newAmount).apply()
        _lives.value = newAmount
    }
    
    fun useLife(): Boolean {
        if (_lives.value > 0) {
            val newAmount = _lives.value - 1
            prefs.edit().putInt("lives", newAmount).apply()
            _lives.value = newAmount
            return true
        }
        return false
    }

    fun addShields(amount: Int) {
        val newAmount = _shields.value + amount
        prefs.edit().putInt("shields", newAmount).apply()
        _shields.value = newAmount
    }
    
    fun useShield(): Boolean {
        if (_shields.value > 0) {
            val newAmount = _shields.value - 1
            prefs.edit().putInt("shields", newAmount).apply()
            _shields.value = newAmount
            return true
        }
        return false
    }

    fun addSkips(amount: Int) {
        val newAmount = _skips.value + amount
        prefs.edit().putInt("skips", newAmount).apply()
        _skips.value = newAmount
    }

    fun unlockItem(id: String) {
        val newSet = _unlockedItems.value.toMutableSet().apply { add(id) }
        prefs.edit().putStringSet("unlocked", newSet).apply()
        _unlockedItems.value = newSet
    }

    fun equipSkin(id: String) {
        prefs.edit().putString("skin", id).apply()
        _equippedSkin.value = id
    }

    fun equipTheme(id: String) {
        prefs.edit().putString("theme", id).apply()
        _equippedTheme.value = id
    }

    fun equipEffect(id: String) {
        prefs.edit().putString("effect", id).apply()
        _equippedEffect.value = id
    }

    private val _hasGivenConsent = MutableStateFlow(prefs.getBoolean("hasGivenConsent", false))
    val hasGivenConsent: StateFlow<Boolean> = _hasGivenConsent.asStateFlow()

    fun setConsent(given: Boolean) {
        prefs.edit().putBoolean("hasGivenConsent", given).apply()
        _hasGivenConsent.value = given
    }
}
