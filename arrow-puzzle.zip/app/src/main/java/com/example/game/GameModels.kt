package com.example.game

enum class Direction {
    UP, DOWN, LEFT, RIGHT;
    
    fun dx(): Int = when (this) {
        LEFT -> -1
        RIGHT -> 1
        else -> 0
    }
    
    fun dy(): Int = when (this) {
        UP -> -1
        DOWN -> 1
        else -> 0
    }
}

data class Block(
    val id: Int,
    val x: Int,
    val y: Int,
    val direction: Direction,
    val colorIndex: Int = 0
)

data class LevelData(
    val levelId: Int,
    val name: String,
    val width: Int,
    val height: Int,
    val blocks: List<Block>
)
