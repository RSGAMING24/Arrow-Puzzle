package com.example.game

import kotlin.math.abs

object LevelFactory {
    fun getLevels(): List<LevelData> {
        val levels = mutableListOf<LevelData>()
        for (i in 1..100) {
            val shapeType = i % 6
            val size = 3 + (i / 15)
            val w = size + 6
            val h = size + 6
            
            val levelName = when (shapeType) {
                0 -> "Box"
                1 -> "Pyramid"
                2 -> "Heart"
                3 -> "Triangle"
                4 -> "Diamond"
                else -> "Circle"
            }
            
            val level = when (shapeType) {
                0 -> createBoxLevel(i, levelName, w, h, size)
                1 -> createPyramidLevel(i, levelName, w, h, size)
                2 -> createHeartLevel(i, levelName, 11, 11)
                3 -> createTriangleLevel(i, levelName, w, h, size)
                4 -> createDiamondLevel(i, levelName, w, h, size / 2 + 1)
                else -> createCircleLevel(i, levelName, w, h, size / 2 + 1)
            }
            levels.add(level)
        }
        return levels
    }

    private var blockIdCounter = 0
    private fun nextId() = blockIdCounter++

    private fun getOutwardDir(dx: Int, dy: Int): Direction {
        return if (abs(dx) >= abs(dy)) {
            if (dx >= 0) Direction.RIGHT else Direction.LEFT
        } else {
            if (dy >= 0) Direction.DOWN else Direction.UP
        }
    }

    private fun createBoxLevel(id: Int, name: String, w: Int, h: Int, size: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val startX = (w - size) / 2
        val startY = (h - size) / 2
        val cx = w / 2
        val cy = h / 2
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (startX + x) - cx
                val dy = (startY + y) - cy
                blocks.add(Block(nextId(), startX + x, startY + y, getOutwardDir(dx, dy)))
            }
        }
        return LevelData(id, name, w, h, blocks)
    }

    private fun createPyramidLevel(id: Int, name: String, w: Int, h: Int, height: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val centerX = w / 2
        val startY = (h - height) / 2
        val cy = h / 2
        for (y in 0 until height) {
            val width = y * 2 + 1
            val startX = centerX - y
            for (x in 0 until width) {
                val dx = (startX + x) - centerX
                val dy = (startY + y) - cy
                blocks.add(Block(nextId(), startX + x, startY + y, getOutwardDir(dx, dy)))
            }
        }
        return LevelData(id, name, w, h, blocks)
    }

    private fun createTriangleLevel(id: Int, name: String, w: Int, h: Int, size: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val startX = (w - size) / 2
        val cx = w / 2
        val cy = h / 2
        for (x in 0 until size) {
            val height = size - x
            val yStart = cy - height / 2
            for (y in 0 until height) {
                val dx = (startX + x) - cx
                val dy = (yStart + y) - cy
                blocks.add(Block(nextId(), startX + x, yStart + y, getOutwardDir(dx, dy)))
            }
        }
        return LevelData(id, name, w, h, blocks)
    }

    private fun createHeartLevel(id: Int, name: String, w: Int, h: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val heartShape = listOf(
            " 01010 ",
            "0111110",
            "0111110",
            " 01110 ",
            "  010  "
        )
        val startX = (w - heartShape[0].length) / 2
        val startY = (h - heartShape.size) / 2
        val cx = w / 2
        val cy = startY + 2
        for ((y, row) in heartShape.withIndex()) {
            for ((x, char) in row.withIndex()) {
                if (char != ' ') {
                    val dx = (startX + x) - cx
                    val dy = (startY + y) - cy
                    blocks.add(Block(nextId(), startX + x, startY + y, getOutwardDir(dx, dy)))
                }
            }
        }
        return LevelData(id, name, w, h, blocks)
    }
    
    private fun createDiamondLevel(id: Int, name: String, w: Int, h: Int, radius: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val cx = w / 2
        val cy = h / 2
        for (y in -radius..radius) {
            for (x in -radius..radius) {
                if (abs(x) + abs(y) <= radius) {
                     blocks.add(Block(nextId(), cx + x, cy + y, getOutwardDir(x, y)))
                }
            }
        }
        return LevelData(id, name, w, h, blocks)
    }

    private fun createCircleLevel(id: Int, name: String, w: Int, h: Int, radius: Int): LevelData {
        val blocks = mutableListOf<Block>()
        val cx = w / 2
        val cy = h / 2
        for (y in -radius..radius) {
            for (x in -radius..radius) {
                if (x*x + y*y <= radius*radius) {
                    blocks.add(Block(nextId(), cx + x, cy + y, getOutwardDir(x, y)))
                }
            }
        }
        return LevelData(id, name, w, h, blocks)
    }
}
