package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ProgressRepository
import com.example.game.LevelData
import com.example.ui.theme.*
import com.example.viewmodel.GameViewModel

import com.example.ads.BannerAdView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: GameViewModel,
    progressRepository: ProgressRepository,
    onLevelSelected: (Int) -> Unit,
    onBack: () -> Unit
) {
    val levels by viewModel.levels.collectAsStateWithLifecycle()
    val allProgress by progressRepository.allProgress.collectAsStateWithLifecycle(initialValue = emptyList())
    val completedLevels = allProgress.filter { it.completed }.map { it.levelId }.toSet()
    val maxUnlocked = (completedLevels.maxOrNull() ?: 0) + 1

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Arrow Puzzle", fontWeight = FontWeight.Bold, color = DarkNavy) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        androidx.compose.material3.Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            BannerAdView()
        },
        containerColor = LightGrayBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(levels) { level ->
                    val isUnlocked = level.levelId <= maxUnlocked
                    val progress = allProgress.find { it.levelId == level.levelId }
                    val stars = progress?.stars ?: 0
                    
                    LevelGridItem(
                        level = level,
                        isUnlocked = isUnlocked,
                        stars = stars,
                        onClick = { if (isUnlocked) onLevelSelected(level.levelId) }
                    )
                }
            }
        }
    }
}

@Composable
fun LevelGridItem(level: LevelData, isUnlocked: Boolean, stars: Int, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .aspectRatio(1f)
            .clickable(enabled = isUnlocked, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) Color.White else Color(0xFFE0E0E0)
        ),
        border = BorderStroke(2.dp, if (isUnlocked) PrimaryBlue else Color.Transparent)
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (isUnlocked) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${level.levelId}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkNavy
                    )
                    Row(modifier = Modifier.padding(top = 4.dp)) {
                        for (i in 1..3) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = if (i <= stars) Color(0xFFFFD700) else Color(0xFFE0E0E0),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            } else {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked",
                    tint = Color(0xFF9E9E9E),
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}
