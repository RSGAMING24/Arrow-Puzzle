package com.example.ui.screens

import android.view.SoundEffectConstants
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import com.example.ads.AdsManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.game.Block
import com.example.game.Direction
import com.example.ui.theme.*
import com.example.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    viewModel: GameViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val level = uiState.currentLevel
    val view = LocalView.current

    val equippedSkin by viewModel.userPreferences.equippedSkin.collectAsStateWithLifecycle()
    val equippedTheme by viewModel.userPreferences.equippedTheme.collectAsStateWithLifecycle()
    val equippedEffect by viewModel.userPreferences.equippedEffect.collectAsStateWithLifecycle()

    var initialBlocks by remember { mutableStateOf<List<Block>>(emptyList()) }
    
    LaunchedEffect(level) {
        if (level != null && uiState.moves == 0) {
            initialBlocks = level.blocks
        }
    }

    val themeBgColor = when (equippedTheme) {
        "theme_dark" -> Color(0xFF121212)
        "theme_space" -> Color(0xFF0B0D17)
        "theme_blueprint" -> Color(0xFF003366)
        else -> Color.White
    }
    
    val themeTextColor = when (equippedTheme) {
        "theme_dark", "theme_space", "theme_blueprint" -> Color.White
        else -> DarkNavy
    }

    val context = LocalContext.current
    val handleBackWithAd = {
        AdsManager.showInterstitial(context as android.app.Activity)
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    val titles1 = listOf("Tap Away", "Find the", "Use", "Clear")
                    val titles2 = listOf("Arrows", "Free Path", "Helpful Hints", "the Board")
                    val idx = level?.let { it.levelId % 4 } ?: 0
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(titles1[idx], fontSize = 16.sp, fontWeight = FontWeight.Bold, color = themeTextColor)
                        Text(titles2[idx], fontSize = 22.sp, fontWeight = FontWeight.Black, color = themeTextColor)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = handleBackWithAd) {
                        Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Settings */ }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = themeBgColor)
            )
        },
        containerColor = themeBgColor
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Dotted Background
            Canvas(modifier = Modifier.fillMaxSize()) {
                val dotRadius = 2f
                val spacing = 60f
                val dotColor = if (equippedTheme == "theme_blueprint") Color.White.copy(alpha=0.3f) 
                               else if (equippedTheme == "theme_dark" || equippedTheme == "theme_space") Color.White.copy(alpha=0.1f) 
                               else DottedGray
                               
                for (x in 0..size.width.toInt() step spacing.toInt()) {
                    for (y in 0..size.height.toInt() step spacing.toInt()) {
                        drawCircle(color = dotColor, radius = dotRadius, center = Offset(x.toFloat(), y.toFloat()))
                    }
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // Header Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Moves
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFF0F4FF)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Default.NearMe, contentDescription = null, tint = DarkNavy, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${uiState.moves}", fontWeight = FontWeight.Bold, color = DarkNavy)
                        }
                    }

                    // Hearts
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        repeat(3) { index ->
                            val isAlive = index < uiState.lives
                            val tint by animateColorAsState(targetValue = if (isAlive) HeartRed else Color.LightGray, animationSpec = tween(500))
                            val scale by animateFloatAsState(targetValue = if (isAlive) 1f else 0.8f, animationSpec = tween(500))
                            val alpha by animateFloatAsState(targetValue = if (isAlive) 1f else 0.4f, animationSpec = tween(500))
                            Icon(
                                Icons.Default.Favorite, 
                                contentDescription = "Life", 
                                tint = tint, 
                                modifier = Modifier.size(20.dp).scale(scale).alpha(alpha)
                            )
                        }
                    }

                    // Difficulty
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFF0F4FF)
                    ) {
                        Text("Level ${level?.levelId ?: ""}", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontWeight = FontWeight.Bold, color = DarkNavy, fontSize = 12.sp)
                    }
                }

                // Game Board
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (level != null) {
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .aspectRatio(level.width.toFloat() / level.height.toFloat())
                        ) {
                            val blockSize = maxWidth / level.width
                            
                            initialBlocks.forEach { block ->
                                val isVisible = uiState.blocks.any { it.id == block.id }
                                
                                Box(
                                    modifier = Modifier
                                        .offset(
                                            x = blockSize * block.x,
                                            y = blockSize * block.y
                                        )
                                        .size(blockSize)
                                        .padding(1.5.dp)
                                ) {
                                    androidx.compose.animation.AnimatedVisibility(
                                        visible = isVisible,
                                        enter = androidx.compose.animation.fadeIn(tween(300)),
                                        exit = slideOut(
                                            targetOffset = {
                                                IntOffset(
                                                    it.width * block.direction.dx() * 5,
                                                    it.height * block.direction.dy() * 5
                                                )
                                            },
                                            animationSpec = tween(300)
                                        ) + fadeOut(tween(300))
                                    ) {
                                        BlockItem(
                                            block = block,
                                            isHighlighted = uiState.highlightedBlockId == block.id,
                                            isError = uiState.errorBlockId == block.id,
                                            equippedSkin = equippedSkin
                                        ) {
                                            val wasRemoved = viewModel.onBlockTapped(block)
                                            if (wasRemoved) {
                                                view.playSoundEffect(SoundEffectConstants.CLICK)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Actions
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(contentAlignment = Alignment.TopEnd) {
                        var hintClickTrigger by remember { mutableStateOf(false) }
                        val hintScale by animateFloatAsState(
                            targetValue = if (hintClickTrigger) 0.8f else 1f,
                            animationSpec = tween(150),
                            finishedListener = { hintClickTrigger = false }
                        )
                        Surface(
                            onClick = { 
                                hintClickTrigger = true
                                viewModel.useHint() 
                            },
                            shape = CircleShape,
                            color = if (uiState.hints > 0) Color.White else Color(0xFFF0F0F0),
                            border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                            modifier = Modifier.size(64.dp).scale(hintScale),
                            shadowElevation = 4.dp
                        ) {
                            Icon(Icons.Outlined.Lightbulb, contentDescription = "Hint", tint = if (uiState.hints > 0) PrimaryBlue else Color.Gray, modifier = Modifier.padding(16.dp))
                        }
                        Badge(containerColor = PrimaryBlue, contentColor = Color.White) { Text("${uiState.hints}") }
                    }
                    Spacer(modifier = Modifier.width(32.dp))
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                        modifier = Modifier.size(64.dp),
                        shadowElevation = 4.dp
                    ) {
                        Icon(Icons.Default.Grid3x3, contentDescription = "Shuffle", tint = PrimaryBlue, modifier = Modifier.padding(16.dp))
                    }
                }
            }
            
            if (uiState.isLevelComplete) {
                LevelCompleteOverlay(handleBackWithAd)
            } else if (uiState.isGameOver) {
                GameOverOverlay(
                    onPlayAgain = {
                        AdsManager.showInterstitial(context as android.app.Activity)
                        viewModel.loadLevel(level?.levelId ?: 1)
                    },
                    onBack = handleBackWithAd
                )
            }
        }
    }
}

@Composable
fun GameOverOverlay(onPlayAgain: () -> Unit, onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            Text(
                text = "Game Over",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = DarkNavy
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onPlayAgain,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text("Play Again", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = onBack) {
                Text("Main Menu", fontSize = 16.sp, color = DarkNavy)
            }
        }
    }
}

@Composable
fun BlockItem(block: Block, isHighlighted: Boolean = false, isError: Boolean = false, equippedSkin: String = "skin_default", onClick: () -> Unit) {
    val shakeAnim = remember { Animatable(0f) }
    
    LaunchedEffect(isError) {
        if (isError) {
            shakeAnim.animateTo(
                targetValue = 1f,
                animationSpec = keyframes {
                    durationMillis = 500
                    0f at 0
                    -10f at 50
                    10f at 150
                    -10f at 250
                    10f at 350
                    0f at 500
                }
            )
        } else {
            shakeAnim.snapTo(0f)
        }
    }

    val highlightPulse = rememberInfiniteTransition()
    val pulseAlpha by highlightPulse.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse"
    )

    val baseColor = when (equippedSkin) {
        "skin_neon" -> Color(0xFF39FF14)
        "skin_golden" -> Color(0xFFFFD700)
        "skin_cyber" -> Color(0xFF00FFFF)
        else -> DarkNavy
    }
    
    val targetColor = when {
        isError -> Color(0xFFFF3333)
        isHighlighted -> Color(0xFFFFD700).copy(alpha = pulseAlpha)
        else -> baseColor
    }
    val animatedColor by animateColorAsState(
        targetValue = targetColor, 
        animationSpec = tween(200)
    )

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .offset(x = shakeAnim.value.dp)
            .clickable { onClick() }
    ) {
        val strokeW = size.width * 0.08f // Thinner stroke
        val color = animatedColor
        
        val cx = size.width / 2
        val cy = size.height / 2
        
        // Longer length to fill the cell more
        val length = size.width * 0.95f 
        val halfLen = length / 2
        
        // Narrower and slightly shorter head
        val headLen = size.width * 0.2f
        val headWidth = size.width * 0.2f
        
        val start: Offset
        val end: Offset
        val head1: Offset
        val head2: Offset

        when (block.direction) {
            Direction.UP -> {
                start = Offset(cx, cy + halfLen)
                end = Offset(cx, cy - halfLen)
                head1 = Offset(cx - headWidth, end.y + headLen)
                head2 = Offset(cx + headWidth, end.y + headLen)
            }
            Direction.DOWN -> {
                start = Offset(cx, cy - halfLen)
                end = Offset(cx, cy + halfLen)
                head1 = Offset(cx - headWidth, end.y - headLen)
                head2 = Offset(cx + headWidth, end.y - headLen)
            }
            Direction.LEFT -> {
                start = Offset(cx + halfLen, cy)
                end = Offset(cx - halfLen, cy)
                head1 = Offset(end.x + headLen, cy - headWidth)
                head2 = Offset(end.x + headLen, cy + headWidth)
            }
            Direction.RIGHT -> {
                start = Offset(cx - halfLen, cy)
                end = Offset(cx + halfLen, cy)
                head1 = Offset(end.x - headLen, cy - headWidth)
                head2 = Offset(end.x - headLen, cy + headWidth)
            }
        }

        // Draw main line
        drawLine(
            color = color,
            start = start,
            end = end,
            strokeWidth = strokeW,
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )

        // Draw arrow head lines with rounded join
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(head1.x, head1.y)
            lineTo(end.x, end.y)
            lineTo(head2.x, head2.y)
        }
        drawPath(
            path = path,
            color = color,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = strokeW,
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
                join = androidx.compose.ui.graphics.StrokeJoin.Round
            )
        )
    }
}

@Composable
fun LevelCompleteOverlay(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF33CCFF), Color(0xFF0066FF)),
                    radius = 1500f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = "Train",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Your Brain",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Level Completed!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            Card(
                modifier = Modifier.size(200.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(80.dp))
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PrimaryBlue),
                modifier = Modifier.fillMaxWidth(0.8f).height(56.dp),
                shape = RoundedCornerShape(28.dp)
            ) {
                Text("Next Level", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            TextButton(
                onClick = onBack,
                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Text("Main", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
