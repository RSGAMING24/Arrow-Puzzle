package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ProgressRepository
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.LightGrayBg
import com.example.ui.theme.PrimaryBlue

import com.example.ads.BannerAdView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    progressRepository: ProgressRepository,
    onNavigateToLevels: () -> Unit,
    onNavigateToShop: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToDaily: () -> Unit,
    onNavigateToAchievements: () -> Unit
) {
    val allProgress by progressRepository.allProgress.collectAsStateWithLifecycle(initialValue = emptyList())
    val completedCount = allProgress.count { it.completed }
    val progressPercent = (completedCount.toFloat() / 100f) * 100f

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = DarkNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = LightGrayBg)
            )
        },
        bottomBar = {
            BannerAdView()
        },
        containerColor = LightGrayBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))
            
            Text(
                text = "ARROW",
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                color = DarkNavy,
                letterSpacing = 2.sp
            )
            Text(
                text = "ESCAPE",
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                color = PrimaryBlue,
                letterSpacing = 2.sp
            )
            Text(
                text = "Tap. Think. Escape.",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = DarkNavy.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Progress Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("LEVEL PROGRESS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkNavy.copy(alpha = 0.6f))
                        Text("$completedCount / 100", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { progressPercent / 100f },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = PrimaryBlue,
                        trackColor = LightGrayBg
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Main Menu Buttons
            MenuButton(icon = Icons.Default.PlayArrow, text = "PLAY", color = PrimaryBlue, textColor = Color.White, onClick = onNavigateToLevels)
            MenuButton(icon = Icons.Default.GridOn, text = "LEVELS", onClick = onNavigateToLevels)
            MenuButton(icon = Icons.Default.CalendarToday, text = "DAILY CHALLENGE", onClick = onNavigateToDaily)
            MenuButton(icon = Icons.Default.ShoppingCart, text = "SHOPPING CENTER", onClick = onNavigateToShop)
            MenuButton(icon = Icons.Default.EmojiEvents, text = "ACHIEVEMENTS", onClick = onNavigateToAchievements)
        }
    }
}

@Composable
fun MenuButton(
    icon: ImageVector,
    text: String,
    color: Color = Color.White,
    textColor: Color = DarkNavy,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = textColor),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .height(64.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (color == Color.White) 2.dp else 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
