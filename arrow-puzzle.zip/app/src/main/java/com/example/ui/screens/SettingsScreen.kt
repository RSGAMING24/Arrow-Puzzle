package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.LightGrayBg
import com.example.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var soundEnabled by remember { mutableStateOf(true) }
    var musicEnabled by remember { mutableStateOf(true) }
    var hapticsEnabled by remember { mutableStateOf(true) }
    var notificationsEnabled by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold, color = DarkNavy) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = LightGrayBg)
            )
        },
        containerColor = LightGrayBg
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("PREFERENCES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkNavy.copy(alpha = 0.6f), modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
                SettingsCard {
                    SettingsToggle("Sound Effects", soundEnabled) { soundEnabled = it }
                    Divider(color = LightGrayBg)
                    SettingsToggle("Background Music", musicEnabled) { musicEnabled = it }
                    Divider(color = LightGrayBg)
                    SettingsToggle("Vibration / Haptics", hapticsEnabled) { hapticsEnabled = it }
                }
            }
            
            item {
                Text("GENERAL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkNavy.copy(alpha = 0.6f), modifier = Modifier.padding(start = 16.dp, bottom = 8.dp, top = 16.dp))
                SettingsCard {
                    SettingsToggle("Push Notifications", notificationsEnabled) { notificationsEnabled = it }
                    Divider(color = LightGrayBg)
                    SettingsButton("Reset Progress", Color(0xFFE53935)) { /* Reset Action */ }
                }
            }
            
            item {
                Text("ABOUT", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkNavy.copy(alpha = 0.6f), modifier = Modifier.padding(start = 16.dp, bottom = 8.dp, top = 16.dp))
                SettingsCard {
                    SettingsButton("Privacy Policy", DarkNavy) { }
                    Divider(color = LightGrayBg)
                    SettingsButton("Terms of Service", DarkNavy) { }
                    Divider(color = LightGrayBg)
                    SettingsButton("App Version: 1.0.0", DarkNavy.copy(alpha = 0.5f)) { }
                }
            }
        }
    }
}

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            content()
        }
    }
}

@Composable
fun SettingsToggle(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = DarkNavy)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PrimaryBlue)
        )
    }
}

@Composable
fun SettingsButton(title: String, textColor: Color, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = textColor)
        }
    }
}
