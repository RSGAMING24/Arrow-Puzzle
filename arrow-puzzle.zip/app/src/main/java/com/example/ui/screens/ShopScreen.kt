package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdsManager
import com.example.ads.BannerAdView
import com.example.data.UserPreferences
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.LightGrayBg
import com.example.ui.theme.PrimaryBlue

enum class ItemType { CONSUMABLE, SKIN, THEME, EFFECT }

data class ShopItemData(
    val id: String,
    val name: String,
    val description: String,
    val price: Int,
    val icon: ImageVector,
    val type: ItemType
)

val shopItems = listOf(
    // Consumables
    ShopItemData("pack_hints", "Hint Pack", "+5 Hints", 300, Icons.Default.Lightbulb, ItemType.CONSUMABLE),
    ShopItemData("pack_lives", "Life Refill", "+1 Extra Life", 200, Icons.Default.Favorite, ItemType.CONSUMABLE),
    ShopItemData("pack_shield", "Touch Shield", "Protects 1 wrong", 250, Icons.Default.Shield, ItemType.CONSUMABLE),
    ShopItemData("pack_skip", "Level Skip", "Skip 1 level", 500, Icons.Default.SkipNext, ItemType.CONSUMABLE),
    
    // Skins
    ShopItemData("skin_neon", "Neon Glow", "Bright glowing arrow", 400, Icons.Default.Palette, ItemType.SKIN),
    ShopItemData("skin_golden", "Golden Arrow", "Pure gold arrow", 800, Icons.Default.Star, ItemType.SKIN),
    ShopItemData("skin_cyber", "Cyber Arrow", "Futuristic design", 600, Icons.Default.ElectricBolt, ItemType.SKIN),
    
    // Themes
    ShopItemData("theme_dark", "Dark Mode", "Dark background", 400, Icons.Default.DarkMode, ItemType.THEME),
    ShopItemData("theme_space", "Space Galaxy", "Cosmic background", 600, Icons.Default.Public, ItemType.THEME),
    ShopItemData("theme_blueprint", "Blueprint", "Architectural style", 500, Icons.Default.Architecture, ItemType.THEME),

    // Effects
    ShopItemData("effect_particle", "Particle Burst", "On touch explosion", 300, Icons.Default.AutoAwesome, ItemType.EFFECT),
    ShopItemData("effect_sparkle", "Sparkle Hit", "Sparkling trail", 300, Icons.Default.Flare, ItemType.EFFECT)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(userPreferences: UserPreferences, onBack: () -> Unit) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("POWER-UPS", "SKINS", "THEMES", "EFFECTS")
    val context = LocalContext.current

    val coins by userPreferences.coins.collectAsStateWithLifecycle()
    val unlockedItems by userPreferences.unlockedItems.collectAsStateWithLifecycle()
    val equippedSkin by userPreferences.equippedSkin.collectAsStateWithLifecycle()
    val equippedTheme by userPreferences.equippedTheme.collectAsStateWithLifecycle()
    val equippedEffect by userPreferences.equippedEffect.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Shopping Center", fontWeight = FontWeight.Bold, color = DarkNavy) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = LightGrayBg)
            )
        },
        bottomBar = {
            BannerAdView()
        },
        containerColor = LightGrayBg
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Watch Ad for Free Hint button
            Button(
                onClick = {
                    AdsManager.showRewarded(context as Activity) {
                        userPreferences.addHints(1)
                        Toast.makeText(context, "Free Hint Unlocked Successfully!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Icon(Icons.Default.OndemandVideo, contentDescription = "Video Ad")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Watch Ad for Free Hint", fontWeight = FontWeight.Bold)
            }

            // Coins Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Logic Coins", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DarkNavy)
                Surface(
                    color = Color(0xFFFFD700).copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("$coins", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color(0xFFD4AF37), modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = LightGrayBg,
                contentColor = PrimaryBlue,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = PrimaryBlue
                        )
                    }
                },
                divider = {}
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = FontWeight.Bold, color = if (selectedTab == index) PrimaryBlue else DarkNavy.copy(alpha = 0.5f)) }
                    )
                }
            }

            // Content
            val currentType = when (selectedTab) {
                0 -> ItemType.CONSUMABLE
                1 -> ItemType.SKIN
                2 -> ItemType.THEME
                else -> ItemType.EFFECT
            }
            val displayedItems = shopItems.filter { it.type == currentType }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(displayedItems.size) { index ->
                    val item = displayedItems[index]
                    val isUnlocked = unlockedItems.contains(item.id) || item.type == ItemType.CONSUMABLE
                    val isEquipped = item.id == equippedSkin || item.id == equippedTheme || item.id == equippedEffect

                    ShopItemView(
                        item = item,
                        isUnlocked = isUnlocked,
                        isEquipped = isEquipped,
                        onBuyClick = {
                            if (item.type == ItemType.CONSUMABLE) {
                                if (userPreferences.spendCoins(item.price)) {
                                    when (item.id) {
                                        "pack_hints" -> userPreferences.addHints(5)
                                        "pack_lives" -> userPreferences.addLives(1)
                                        "pack_shield" -> userPreferences.addShields(1)
                                        "pack_skip" -> userPreferences.addSkips(1)
                                    }
                                    Toast.makeText(context, "Purchased ${item.name}!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Not enough Logic Coins!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                if (isUnlocked) {
                                    // Equip
                                    when (item.type) {
                                        ItemType.SKIN -> userPreferences.equipSkin(item.id)
                                        ItemType.THEME -> userPreferences.equipTheme(item.id)
                                        ItemType.EFFECT -> userPreferences.equipEffect(item.id)
                                        else -> {}
                                    }
                                } else {
                                    // Buy
                                    if (userPreferences.spendCoins(item.price)) {
                                        userPreferences.unlockItem(item.id)
                                        Toast.makeText(context, "Purchased!", Toast.LENGTH_SHORT).show()
                                        // Auto-equip on purchase
                                        when (item.type) {
                                            ItemType.SKIN -> userPreferences.equipSkin(item.id)
                                            ItemType.THEME -> userPreferences.equipTheme(item.id)
                                            ItemType.EFFECT -> userPreferences.equipEffect(item.id)
                                            else -> {}
                                        }
                                    } else {
                                        Toast.makeText(context, "Not enough Logic Coins!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        onAdClick = {
                            if (!isUnlocked && item.type != ItemType.CONSUMABLE) {
                                AdsManager.showRewarded(context as Activity) {
                                    userPreferences.unlockItem(item.id)
                                    Toast.makeText(context, "Unlocked Successfully!", Toast.LENGTH_SHORT).show()
                                    when (item.type) {
                                        ItemType.SKIN -> userPreferences.equipSkin(item.id)
                                        ItemType.THEME -> userPreferences.equipTheme(item.id)
                                        ItemType.EFFECT -> userPreferences.equipEffect(item.id)
                                        else -> {}
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ShopItemView(
    item: ShopItemData,
    isUnlocked: Boolean,
    isEquipped: Boolean,
    onBuyClick: () -> Unit,
    onAdClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(2.dp, if (isEquipped) PrimaryBlue else if (isUnlocked) PrimaryBlue.copy(alpha=0.3f) else Color(0xFFE0E0E0)),
        modifier = Modifier.clickable { onBuyClick() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(LightGrayBg, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(item.icon, contentDescription = null, tint = if (isUnlocked) PrimaryBlue else Color.Gray, modifier = Modifier.size(32.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(item.name, fontWeight = FontWeight.Bold, color = DarkNavy, fontSize = 14.sp, textAlign = TextAlign.Center)
            Text(item.description, color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.height(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            
            if (item.type == ItemType.CONSUMABLE) {
                Text("${item.price} Coins", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD4AF37))
            } else {
                if (isEquipped) {
                    Text("EQUIPPED", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                } else if (!isUnlocked) {
                    Text("${item.price} Coins", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD4AF37))
                    Spacer(modifier = Modifier.height(4.dp))
                    IconButton(
                        onClick = onAdClick,
                        modifier = Modifier.size(32.dp).background(Color(0xFFFF5722), RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.OndemandVideo, contentDescription = "Watch Ad", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                } else {
                    Text("EQUIP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkNavy)
                }
            }
        }
    }
}
