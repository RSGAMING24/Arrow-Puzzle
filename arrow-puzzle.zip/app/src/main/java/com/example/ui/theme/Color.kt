package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkNavy = Color(0xFF192038)
val PrimaryBlue = Color(0xFF3399FF)
val LightGrayBg = Color(0xFFF8F9FA)
val HeartRed = Color(0xFFE53935)
val DottedGray = Color(0xFFDCDCDC)
