package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProgressRepository
import com.example.data.UserPreferences
import com.example.game.Block
import com.example.game.LevelData
import com.example.game.LevelFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameState(
    val currentLevel: LevelData? = null,
    val blocks: List<Block> = emptyList(),
    val isLevelComplete: Boolean = false,
    val moves: Int = 0,
    val lives: Int = 3,
    val hints: Int = 2,
    val isGameOver: Boolean = false,
    val highlightedBlockId: Int? = null,
    val errorBlockId: Int? = null
)

class GameViewModel(
    private val progressRepository: ProgressRepository,
    val userPreferences: UserPreferences
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameState())
    val uiState: StateFlow<GameState> = _uiState.asStateFlow()
    
    private val _levels = MutableStateFlow(LevelFactory.getLevels())
    val levels: StateFlow<List<LevelData>> = _levels.asStateFlow()

    fun loadLevel(levelId: Int) {
        val level = _levels.value.find { it.levelId == levelId } ?: return
        _uiState.update { 
            it.copy(
                currentLevel = level,
                blocks = level.blocks,
                isLevelComplete = false,
                moves = 0,
                lives = userPreferences.lives.value,
                hints = userPreferences.hints.value,
                isGameOver = false,
                highlightedBlockId = null,
                errorBlockId = null
            )
        }
    }

    fun onBlockTapped(block: Block): Boolean {
        val state = _uiState.value
        if (state.isGameOver || state.isLevelComplete) return false
        if (state.errorBlockId != null) return false
        val level = state.currentLevel ?: return false
        
        if (canMove(block, state.blocks, level.width, level.height)) {
            val newBlocks = state.blocks.filter { it.id != block.id }
            val isComplete = newBlocks.isEmpty()
            val stars = when (state.lives) {
                3 -> 3
                2 -> 2
                else -> 1
            }
            _uiState.update { 
                it.copy(
                    blocks = newBlocks,
                    moves = it.moves + 1,
                    isLevelComplete = isComplete
                )
            }
            if (isComplete) {
                viewModelScope.launch {
                    progressRepository.saveProgress(level.levelId, stars)
                }
            }
            return true
        } else {
            _uiState.update { it.copy(errorBlockId = block.id) }
            viewModelScope.launch {
                kotlinx.coroutines.delay(500)
                val currentState = _uiState.value
                val newLives = maxOf(0, currentState.lives - 1)
                userPreferences.useLife() // Keep shared preferences in sync
                _uiState.update {
                    it.copy(
                        errorBlockId = null,
                        lives = newLives,
                        isGameOver = newLives == 0
                    )
                }
            }
            return false
        }
    }

    fun useHint() {
        val state = _uiState.value
        if (state.hints > 0 && !state.isGameOver && !state.isLevelComplete) {
            val level = state.currentLevel ?: return
            val unblockedArrow = state.blocks.find { canMove(it, state.blocks, level.width, level.height) }
            if (unblockedArrow != null) {
                userPreferences.useHint() // Sync with preferences
                _uiState.update { it.copy(hints = it.hints - 1, highlightedBlockId = unblockedArrow.id) }
                viewModelScope.launch {
                    kotlinx.coroutines.delay(2500)
                    _uiState.update { it.copy(highlightedBlockId = if (it.highlightedBlockId == unblockedArrow.id) null else it.highlightedBlockId) }
                }
            }
        }
    }

    private fun canMove(block: Block, allBlocks: List<Block>, w: Int, h: Int): Boolean {
        var currX = block.x + block.direction.dx()
        var currY = block.y + block.direction.dy()
        
        while (currX in 0 until w && currY in 0 until h) {
            if (allBlocks.any { it.x == currX && it.y == currY }) {
                return false
            }
            currX += block.direction.dx()
            currY += block.direction.dy()
        }
        return true
    }
}
